var tratar_dados_obtidos = function(dados_obtidos){
	document.getElementById("local_consulta_2").innerHTML = dados_obtidos;
};
carregar_dados("php/aplicacao/consultas/consulta_2.php", tratar_dados_obtidos);

var formulario = document.forms.namedItem("formulario_envio");
formulario.addEventListener('submit', function(ev){
	ev.preventDefault();
	var dados_formulario = new FormData(this);
	carregar_dados("php/aplicacao/consultas/consulta_1.php", tratar_dados_obtidos, "POST", dados_formulario);
}, false);