<header>
	<h1>MONITORAMENTO DE LINHAS DE TRANSMISSÃO - IT548</h1>
	<nav>
		<ul>
			<li><a id="menu_index" href="index.php">Mapa</a></li>
			<li><a id="menu_consulta_1" href="consulta_1.php">C1</a></li>
			<li><a id="menu_consulta_2" href="consulta_2.php">C2</a></li>
			<li><a id="menu_consulta_3" href="consulta_3.php">C3</a></li>
			<li><a id="menu_consulta_4" href="consulta_4.php">C4</a></li>
			<li><a id="menu_imagem" href="imagem.php">Imagem</a></li>
			<li><a id="menu_python" href="python.php">Python</a></li>
		</ul>
	</nav>
</header>