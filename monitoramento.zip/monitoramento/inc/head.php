<meta name="viewport" content="initial-scale=1.0, user-scalable=no"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<link rel="apple-touch-icon" sizes="180x180" href="media/ico/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="media/ico/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="media/ico/favicon-16x16.png">
<link rel="manifest" href="media/ico/site.webmanifest">
<title>Monitoramento SBD</title>
<link rel="stylesheet" type="text/css" href="css/layout.css?versao=<?php echo $versao; ?>">
<script src="js/comum/funcoes.js?versao=<?php echo $versao; ?>"></script>