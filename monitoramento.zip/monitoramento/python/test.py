a, b = 0, 1
while a < 20:
    print(a)
    a, b = b, a+b