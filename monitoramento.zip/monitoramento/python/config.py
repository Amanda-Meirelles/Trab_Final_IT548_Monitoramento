mysql={
    'host': 'localhost',
    'database': 'sbd_imobiliaria',
    'user': 'sbd_imobiliaria',
    'password': '123'
}