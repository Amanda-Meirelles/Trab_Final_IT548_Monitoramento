<?php

return [
    "EPSG:32635" => "+proj=utm +zone=35 +datum=WGS84 +units=m +no_defs",
];
