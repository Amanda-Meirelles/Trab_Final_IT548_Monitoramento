<?php

return [
    "EPSG:32637" => "+proj=utm +zone=37 +datum=WGS84 +units=m +no_defs",
];
