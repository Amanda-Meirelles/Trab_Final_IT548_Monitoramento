<?php

return [
    "EPSG:32638" => "+proj=utm +zone=38 +datum=WGS84 +units=m +no_defs",
];
