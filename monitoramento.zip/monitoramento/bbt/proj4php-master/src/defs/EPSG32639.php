<?php

return [
    "EPSG:32639" => "+proj=utm +zone=39 +datum=WGS84 +units=m +no_defs",
];
