<?php

return [
    "EPSG:4272" => "+title=NZGD49 +proj=longlat +ellps=intl +datum=nzgd49 +no_defs",
];
