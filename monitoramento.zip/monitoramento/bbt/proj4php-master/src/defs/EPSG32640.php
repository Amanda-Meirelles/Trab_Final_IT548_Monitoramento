<?php

return [
    "EPSG:32640" => "+proj=utm +zone=40 +datum=WGS84 +units=m +no_defs",
];
