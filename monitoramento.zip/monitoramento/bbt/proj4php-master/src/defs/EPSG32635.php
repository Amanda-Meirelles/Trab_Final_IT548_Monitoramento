<?php

return [
    "EPSG:32636" => "+proj=utm +zone=36 +datum=WGS84 +units=m +no_defs",
];
