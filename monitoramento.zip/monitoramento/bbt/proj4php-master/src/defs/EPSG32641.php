<?php

return [
    "EPSG:32641" => "+proj=utm +zone=41 +datum=WGS84 +units=m +no_defs ",
];
