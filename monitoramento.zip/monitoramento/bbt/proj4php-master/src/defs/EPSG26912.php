<?php

return [
    "EPSG:26912" => "+title=NAD83 / UTM zone 12N +proj=utm +zone=12 +a=6378137.0 +b=6356752.3141403",
];
