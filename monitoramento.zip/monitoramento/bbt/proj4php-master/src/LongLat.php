<?php

namespace proj4php;

/**
 * Author : Julien Moquet
 * 
 * Inspired by Proj4js from Mike Adair madairATdmsolutions.ca
 * and Richard Greenwood rich@greenwoodmap.com 
 * License: LGPL as per: http://www.gnu.org/copyleft/lesser.html 
 */
class LongLat
{
    public function init()
    {
    }

    public function forward($point)
    {
        return $point;
    }

    public function inverse($point)
    {
        return $point;
    }
}
