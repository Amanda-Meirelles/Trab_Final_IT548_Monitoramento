<?PHP
	require_once("../../../config/config.php");
	require_once("../../../comum/funcoes.php");
	$localizacao_id = $_GET['localizacao_id'];
	$empresa_id = $_GET['empresa_id']; 
	$municipio = $_GET['municipio'];
	$estado = $_GET['estado']; 
	$regional = $_GET['regional'];
	echo $localizacao_id;
	echo " - ";
	echo $empresa_id;
	echo " - ";
	echo $municipio;
	echo " - ";
	echo $estado;
	echo " - ";
	echo $regional;
	$geometria = $_GET['geometria'];
	$geometria = "POLYGON((".$geometria."))";
	$conexao=conectar($dados_conexao);
		$consulta = "
					INSERT INTO localizacao(municipio, estado, regional)
					VALUES(?, ?, ?)
				";
	$stmt = mysqli_prepare($conexao, $consulta);
	if (!$stmt) {
		sair(mysqli_error($conexao), $conexao);
	}
	mysqli_stmt_bind_param($stmt, "sss", $municipio, $estado, $regional);
	$sucesso = mysqli_stmt_execute($stmt);
	if (!$sucesso){
		sair(mysqli_stmt_error($stmt), $conexao, $stmt);
	}
	mysqli_stmt_close($stmt);
	$localizacao_id = mysqli_insert_id($conexao);
	$consulta = "
					INSERT INTO linha_transmissao(poligono, localizacao_id, empresa_id)
					VALUES(ST_GeomFromText(?, 4326), ?, ?)
				";
	$stmt = mysqli_prepare($conexao, $consulta);
	if (!$stmt) {
		sair(mysqli_error($conexao), $conexao);
	}
	mysqli_stmt_bind_param($stmt, "sii", $geometria, $localizacao_id, $empresa_id);
	$sucesso = mysqli_stmt_execute($stmt);
	if (!$sucesso){
		sair(mysqli_stmt_error($stmt), $conexao, $stmt);
	}
	mysqli_stmt_close($stmt);
	mysqli_close($conexao);
	exit;
	mysqli_close($conexao);
	exit;
?>