<?PHP
	require_once("../../../config/config.php");
	require_once("../../../comum/funcoes.php");
	function parseToXML($htmlStr){
		$xmlStr=str_replace('<','&lt;',$htmlStr);
		$xmlStr=str_replace('>','&gt;',$xmlStr);
		$xmlStr=str_replace('"','&quot;',$xmlStr);
		$xmlStr=str_replace("'",'&#39;',$xmlStr);
		$xmlStr=str_replace("&",'&amp;',$xmlStr);
		return $xmlStr;
	}
	$conexao=conectar($dados_conexao);
	$consulta = "	
				SELECT lt.empresa_id, lt.localizacao_id, l.municipio, l.estado, l.regional, e.razao_social,
				ST_AsText(lt.poligono) as geometria,
				ST_X (st_centroid(st_geomfromtext(st_astext(st_srid(lt.poligono, 0)), 0))) as longitude,
				ST_Y (st_centroid(st_geomfromtext(st_astext(st_srid(lt.poligono, 0)), 0))) as latitude
				FROM linha_transmissao lt, localizacao l, empresa e
				WHERE lt.localizacao_id = l.id AND e.id= lt.empresa_id
			";
	$resultado_consulta = mysqli_query($conexao, $consulta);
	if (!$resultado_consulta){
		sair("Consulta inválida: ".mysqli_error($conexao), $conexao);
	}

	header("Content-type: text/xml");

	$xml = new DOMDocument("1.0");
	$xml->formatOutput=true;

	$linhas_transmissoes=$xml->createElement("linhas_transmissoes");
	$xml->appendChild($linhas_transmissoes);

	while ($linha = mysqli_fetch_assoc($resultado_consulta)){
		$linha_transmissao=$xml->createElement("linha_transmissao");
		$linhas_transmissoes->appendChild($linha_transmissao);

		$empresa_id=$xml->createElement("empresa_id", $linha["empresa_id"]);
		$linha_transmissao->appendChild($empresa_id);

		$localizacao_id=$xml->createElement("localizacao_id", $linha["localizacao_id"]);
		$linha_transmissao->appendChild($localizacao_id);

		$longitude=$xml->createElement("longitude", $linha["longitude"]);
		$linha_transmissao->appendChild($longitude);
		
		$latitude=$xml->createElement("latitude", $linha["latitude"]);
		$linha_transmissao->appendChild($latitude);
		
		$municipio=$xml->createElement("municipio", $linha["municipio"]);
		$linha_transmissao->appendChild($municipio);
		
		$estado=$xml->createElement("estado", $linha["estado"]);
		$linha_transmissao->appendChild($estado);
		
		$regional=$xml->createElement("regional", $linha["regional"]);
		$linha_transmissao->appendChild($regional);
		
		$razao_social=$xml->createElement("razao_social", $linha["razao_social"]);
		$linha_transmissao->appendChild($razao_social);
		
		$geometria=$xml->createElement("geometria", $linha["geometria"]);
		$linha_transmissao->appendChild($geometria);
	}
	echo $xml->saveXML();
?>