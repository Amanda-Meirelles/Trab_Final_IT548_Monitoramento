<?php
	require_once("../../config/config.php");
	require_once("../../comum/funcoes.php");
	$conexao=conectar($dados_conexao);
	$consulta = "
				SELECT c.tipo, count(*) as qt_deteccoes 
				FROM classificacao c, deteccao d 
				WHERE c.id = d.classificacao_id 
				GROUP BY c.id 
				ORDER BY qt_deteccoes DESC;
			";
	$resultado_consulta = mysqli_query($conexao, $consulta);
	if (!$resultado_consulta) {
		sair("Consulta inválida: ".mysqli_error($conexao), $conexao);
	}
	echo "<table class='tabela_resultado'>";
	echo "<tr><th>Classificação</th><th>Quantidade</th></tr>";
	while ($linha = mysqli_fetch_assoc($resultado_consulta)){
		echo "<tr>";
		echo "<td>".$linha["tipo"]."</td><td>".$linha["qt_deteccoes"]."</td>";
		echo "</tr>";
	}
	echo "</table>";
?>