<?php
	require_once("../../config/config.php");
	require_once("../../comum/funcoes.php");
	$conexao=conectar($dados_conexao);
	$consulta = "
				SELECT loc.estado, count(loc.estado) as qt_linhas
				FROM localizacao loc, linha_transmissao lt
				WHERE estado NOT LIKE 'SP' AND loc.id = lt.localizacao_id 
				GROUP BY loc.estado 
				ORDER BY qt_linhas ASC;
			";
	$resultado_consulta = mysqli_query($conexao, $consulta);
	if (!$resultado_consulta) {
		sair("Consulta inválida: ".mysqli_error($conexao), $conexao);
	}
	echo "<table class='tabela_resultado'>";
	echo "<tr><th>Estado</th><th>Qtd de Linhas de Transmissão</th></tr>";
	while ($linha = mysqli_fetch_assoc($resultado_consulta)){
		echo "<tr>";
		echo "<td>".$linha["estado"]."</td><td>".$linha["qt_linhas"]."</td>";
		echo "</tr>";
	}
	echo "</table>";
?>