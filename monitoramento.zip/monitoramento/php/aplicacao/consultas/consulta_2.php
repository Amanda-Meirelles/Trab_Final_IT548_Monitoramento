<?php
	require_once("../../config/config.php");
	require_once("../../comum/funcoes.php");
	$conexao=conectar($dados_conexao);
	$consulta = "
				SELECT n.nome, f.id, a.crea
				FROM pessoa n, funcionario f, analista a
				WHERE n.id = f.pessoa_id AND f.id = a.funcionarios_id AND n.nome BETWEEN 'A' and 'M'
				ORDER BY nome ASC
				LIMIT 0,5;
			";
	$resultado_consulta = mysqli_query($conexao, $consulta);
	if (!$resultado_consulta){
		sair("Consulta inválida: ".mysqli_error($conexao), $conexao);
	}
	echo "<table class='tabela_resultado'>";
	echo "<tr><th>Analista</th><th>CREA</th></tr>";
	while ($linha = mysqli_fetch_assoc($resultado_consulta)){
		echo "<tr>";
		echo "<td>".$linha["nome"]."</td><td>". $linha["crea"]."</td><td>";
		echo "</tr>";
	}
	echo "</table>";
?>