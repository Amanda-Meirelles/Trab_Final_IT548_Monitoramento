<?php
	require_once("../../config/config.php");
	require_once("../../comum/funcoes.php");
	$conexao=conectar($dados_conexao);
	$consulta = "
				SELECT lt.id, loc.municipio, loc.regional, ST_AsGeoJSON(st_srid(lt.poligono, 32723)) as geometria, 
				ST_AsGeoJSON(st_centroid(st_geomfromtext(st_astext(st_srid(lt.poligono, 0)), 32723))) as centroide, 
				(ST_Area(lt.poligono)* 0.3048) ^ 2 as area
				FROM linha_transmissao lt, localizacao loc
				Where lt.localizacao_id = loc.id AND estado LIKE 'RJ';
			";
	$resultado_consulta = mysqli_query($conexao, $consulta);
	if (!$resultado_consulta) {
		sair("Consulta inválida: ".mysqli_error($conexao), $conexao);
	}
	echo "<table class='tabela_resultado'>";
	echo "<tr><th>ID LT</th><th>Municipio</th><th>Regional</th><th>Geometria</th><th>Centroide</th><th>Area</th></tr>";
	while ($linha = mysqli_fetch_assoc($resultado_consulta)){
		echo "<tr>";
		echo "<td>".$linha["id"]."</td><td>".$linha["municipio"]."</td><td>".$linha["regional"]."</td><td>".$linha["geometria"]."</td><td>".$linha["centroide"]."</td><td>".$linha["area"]."</td>";
		echo "</tr>";
	}
	echo "</table>";
?>