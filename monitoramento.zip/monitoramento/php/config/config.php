<?php
	$dados_conexao["usuario_mysql"]="usuario_compartilhado";
	$dados_conexao["senha_usuario_mysql"]="@compartilhado";//coloque sua senha do mysql
	$dados_conexao["nome_banco_de_dados"]="monitoramento";
	$dados_conexao["nome_servidor"]="localhost";
	$versao=1;
	$local_logs="c:\\Apache24\\htdocs\\monitoramento\\log\\";
	$path_projeto="c:\\Apache24\\htdocs\\monitoramento\\";
?>