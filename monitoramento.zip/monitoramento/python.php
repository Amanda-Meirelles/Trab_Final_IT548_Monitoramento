<!DOCTYPE html>
<html>
	<head>
		<?php
		require_once("php/config/config.php");
		require_once("inc/head.php");
		?>
	</head>
	<body>
		<?php require_once("inc/header.php"); ?>
		<br>
		<div id="resultado_python">
		</div>
	</body>
	<script src="js/python/python.js?versao=<?php echo $versao; ?>"></script>
</html>